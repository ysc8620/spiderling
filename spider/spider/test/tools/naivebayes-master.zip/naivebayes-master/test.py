from naivebayes import NaiveBayes

classes = {'chinese': [['chinese', 'beijing', 'chinese'],
                       ['chinese', 'chinese', 'shanghai'],
                       ['chinese', 'macao']],
           'japanese': [['tokyo', 'japan', 'chinese']]}

test_document = ['chinese', 'chinese', 'chinese', 'tokyo', 'japan']

for klass in classes:
    print("Documents for class '%s'" % klass)
    for document in classes[klass]:
        print(', '.join(document))
    print('')

classifier = NaiveBayes()

classifier.train(classes)

scores = classifier.scores(test_document)

print("Class scores")
for klass in scores:
    print("%s: %f" % (klass, scores[klass]))
print('')

classification = classifier.classify(test_document)

print("Classified as '%s'" % classification)
