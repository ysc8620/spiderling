<?php
$TS_DB['host'] = 'localhost';
$TS_DB['user'] = 'root';
$TS_DB['pwd'] = 'LEsc2008';
$TS_DB['name'] = 'test';

require_once("mysqli.php");

$db = new mysql($TS_DB);


function get_client_real_ip(){
    if(getenv("HTTP_CLIENT_IP") && strcasecmp(getenv("HTTP_CLIENT_IP"), "unknow")){
        $ip = getenv("HTTP_CLIENT_IP");
    }else if(getenv("HTTP_X_FORWARDED_FOR") && strcasecmp(getenv("HTTP_X_FORWARDED_FOR"), "unknow")){
        $ip = getenv("HTTP_X_FORWARDED_FOR");
    }else if(getenv("REMOTE_ADDR") && strcasecmp(getenv("REMOTE_ADDR"), "unknow")){
        $ip = getenv("REMOTE_ADDR");
    }else if(isset($_SERVER["REMOTE_ADDR"]) && $_SERVER["REMOTE_ADDR"] && strcasecmp($_SERVER["REMOTE_ADDR"],"unknow")){
        $ip = $_SERVER["REMOTE_ADDR"];
    }else{
        $ip = "unknow";
    }
    return $ip;
}
function htmlspecialchars_uni($text, $entities = true){
    $text = addslashes($text);
    return str_replace(
    // replace special html characters
        array('<', '>', '"'),
        array('&lt;', '&gt;', '&quot;'),
        preg_replace(
        // translates all non-unicode entities
            '/&(?!' . ($entities ? '#[0-9]+' : '(#[0-9]+|[a-z]+)') . ';)/si',
            '&amp;',
            $text
        )
    );
}


$data['product'] = htmlspecialchars_uni($_POST['title']);
$data['user'] = htmlspecialchars_uni($_POST['niname']);
$data['phone'] = htmlspecialchars_uni($_POST['tel']);
$data['qq'] = htmlspecialchars_uni($_POST['qq']);
$data['address'] = htmlspecialchars_uni($_POST['address']);
$data['num'] = htmlspecialchars_uni($_POST['sl']);
$data['ip'] = get_client_real_ip();
$data['remark'] = htmlspecialchars_uni($_POST['content']);
$db->insertArr($data, 'test2');
?>
