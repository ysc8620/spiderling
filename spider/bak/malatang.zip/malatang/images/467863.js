var online=new Array();
document.write("<script language=\"javascript\" src=\"http://webpresence.qq.com/getonline?Type=1&1198942862:1277992707:774373462:1312443975:\" charset=\"utf-8\" type=\"text/javascript\"></script>");
document.write("<script language=\"javascript\" src=\"http://code2.54kefu.net/kefu/url.js\" charset=\"utf-8\" type=\"text/javascript\"></script>");
